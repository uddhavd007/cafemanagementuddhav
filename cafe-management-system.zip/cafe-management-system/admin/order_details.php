<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT o.*, t.table_number, u.name AS staff_name, c.name AS customer_name
                        FROM orders o
                        LEFT JOIN cafe_tables t ON o.table_id = t.table_id
                        LEFT JOIN users u ON o.staff_id = u.user_id
                        LEFT JOIN users c ON o.customer_id = c.user_id
                        WHERE o.order_id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order) { flash('error', 'Order not found.'); redirect('admin/orders.php'); }

$items = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$items->execute([$id]);
$items = $items->fetchAll();

$pageTitle = 'Order ' . $order['order_number'];
$pageSubtitle = 'Order details & status';

include __DIR__ . '/../includes/header.php';
?>

<div class="grid grid-2" style="align-items:start;">
    <div class="ticket">
        <div class="ticket-head">
            <div>
                <div class="t-num"><?= clean($order['order_number']) ?></div>
                <div class="t-meta"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></div>
            </div>
            <span class="badge <?= status_badge_class($order['status']) ?>"><?= clean($order['status']) ?></span>
        </div>
        <p class="muted" style="margin:0;">
            <?= $order['table_number'] ? 'Table ' . clean($order['table_number']) : ucfirst(str_replace('_',' ',$order['order_type'])) ?>
            <?php if ($order['customer_name']): ?> • <?= clean($order['customer_name']) ?><?php endif; ?>
            <?php if ($order['staff_name']): ?> • served by <?= clean($order['staff_name']) ?><?php endif; ?>
        </p>
        <div class="ticket-items">
            <?php foreach ($items as $it): ?>
                <div class="ti-row">
                    <span class="ti-name"><?= clean($it['item_name']) ?> <span class="ti-qty">× <?= (int)$it['quantity'] ?></span></span>
                    <span><?= format_price($it['subtotal']) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="ti-row"><span class="muted">Subtotal</span><span><?= format_price($order['subtotal']) ?></span></div>
        <div class="ti-row"><span class="muted">Tax</span><span><?= format_price($order['tax_amount']) ?></span></div>
        <?php if ($order['discount'] > 0): ?><div class="ti-row"><span class="muted">Discount</span><span>-<?= format_price($order['discount']) ?></span></div><?php endif; ?>
        <div class="ticket-total" style="margin-top:8px;"><span>Total</span><span><?= format_price($order['grand_total']) ?></span></div>
        <div class="ticket-foot">
            <span class="badge <?= status_badge_class($order['payment_status']) ?>"><?= clean($order['payment_status']) ?><?= $order['payment_method'] ? ' · ' . strtoupper($order['payment_method']) : '' ?></span>
        </div>
    </div>

    <div class="card">
        <h3 class="mt-0">Update Status</h3>
        <form action="ajax/orders.php?action=update_status" method="POST">
            <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
            <label>Order Status</label>
            <select name="status">
                <?php foreach (['pending','preparing','ready','served','completed','cancelled'] as $s): ?>
                    <option value="<?= $s ?>" <?= $order['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-block">Update Status</button>
        </form>

        <form action="ajax/orders.php?action=update_payment" method="POST" style="margin-top:20px;">
            <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
            <label>Payment Status</label>
            <select name="payment_status">
                <option value="unpaid" <?= $order['payment_status']==='unpaid'?'selected':'' ?>>Unpaid</option>
                <option value="paid" <?= $order['payment_status']==='paid'?'selected':'' ?>>Paid</option>
            </select>
            <label>Payment Method</label>
            <select name="payment_method">
                <option value="cash" <?= $order['payment_method']==='cash'?'selected':'' ?>>Cash</option>
                <option value="card" <?= $order['payment_method']==='card'?'selected':'' ?>>Card</option>
                <option value="upi" <?= $order['payment_method']==='upi'?'selected':'' ?>>UPI</option>
            </select>
            <button type="submit" class="btn btn-sage btn-block">Update Payment</button>
        </form>

        <a href="orders.php" class="btn btn-outline btn-block" style="margin-top:20px;">← Back to Orders</a>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
