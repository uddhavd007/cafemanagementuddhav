<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$pageTitle = 'Reports';
$pageSubtitle = 'Sales performance over the last 14 days';

// Sales for last 14 days
$sales = $pdo->query("
    SELECT DATE(created_at) d, SUM(grand_total) total
    FROM orders
    WHERE status != 'cancelled' AND created_at >= (CURDATE() - INTERVAL 14 DAY)
    GROUP BY DATE(created_at)
    ORDER BY d
")->fetchAll();

$labels = [];
$data = [];
foreach ($sales as $s) {
    $labels[] = date('d M', strtotime($s['d']));
    $data[] = (float) $s['total'];
}

$topItems = $pdo->query("
    SELECT item_name, SUM(quantity) qty, SUM(subtotal) revenue
    FROM order_items oi JOIN orders o ON oi.order_id = o.order_id
    WHERE o.status != 'cancelled'
    GROUP BY item_name ORDER BY qty DESC LIMIT 8
")->fetchAll();

$overall = $pdo->query("SELECT COUNT(*) c, COALESCE(SUM(grand_total),0) s FROM orders WHERE status != 'cancelled'")->fetch();
$avgOrder = $overall['c'] > 0 ? $overall['s'] / $overall['c'] : 0;

include __DIR__ . '/../includes/header.php';
?>

<div class="grid grid-3" style="margin-bottom:20px;">
    <div class="card stat-card">
        <div class="stat-label">Total Revenue</div>
        <div class="stat-value"><?= format_price($overall['s']) ?></div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Total Orders</div>
        <div class="stat-value"><?= (int)$overall['c'] ?></div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Average Order Value</div>
        <div class="stat-value"><?= format_price($avgOrder) ?></div>
    </div>
</div>

<div class="card" style="margin-bottom:20px;">
    <h3 class="mt-0">Sales — Last 14 Days</h3>
    <canvas id="salesChart" height="90"></canvas>
</div>

<div class="card">
    <h3 class="mt-0">Top Items by Quantity Sold</h3>
    <table class="data-table" style="margin-top:10px;">
        <thead><tr><th>Item</th><th>Qty Sold</th><th>Revenue</th></tr></thead>
        <tbody>
        <?php foreach ($topItems as $t): ?>
            <tr><td><?= clean($t['item_name']) ?></td><td class="gold"><?= (int)$t['qty'] ?></td><td><?= format_price($t['revenue']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$extraScripts = '
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const ctx = document.getElementById("salesChart");
new Chart(ctx, {
    type: "line",
    data: {
        labels: ' . json_encode($labels) . ',
        datasets: [{
            label: "Revenue (' . CURRENCY . ')",
            data: ' . json_encode($data) . ',
            borderColor: "#E3A548",
            backgroundColor: "rgba(227,165,72,0.15)",
            tension: 0.35,
            fill: true,
            pointBackgroundColor: "#E3A548"
        }]
    },
    options: {
        plugins: { legend: { labels: { color: "#B9A996" } } },
        scales: {
            x: { ticks: { color: "#B9A996" }, grid: { color: "#3B2C22" } },
            y: { ticks: { color: "#B9A996" }, grid: { color: "#3B2C22" } }
        }
    }
});
</script>';
include __DIR__ . '/../includes/footer.php';
?>
