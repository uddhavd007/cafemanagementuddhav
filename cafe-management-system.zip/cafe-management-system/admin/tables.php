<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$pageTitle = 'Table Management';
$pageSubtitle = 'Manage physical cafe tables';
$topbarActions = '<button class="btn btn-primary" onclick="openModal(\'tableModal\')">+ Add Table</button>';

$tables = $pdo->query("SELECT * FROM cafe_tables ORDER BY table_number")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="grid grid-4">
    <?php foreach ($tables as $t): ?>
        <div class="card">
            <div class="flex-between">
                <h3 class="mt-0"><?= clean($t['table_number']) ?></h3>
                <span class="badge <?= status_badge_class($t['status']) ?>"><?= clean($t['status']) ?></span>
            </div>
            <p style="margin:4px 0 14px;">Seats <?= (int)$t['capacity'] ?></p>
            <div class="flex gap-8">
                <form action="ajax/tables.php?action=set_status" method="POST" style="flex:1;">
                    <input type="hidden" name="table_id" value="<?= $t['table_id'] ?>">
                    <select name="status" onchange="this.form.submit()" style="margin-bottom:0;">
                        <option value="available" <?= $t['status']=='available'?'selected':'' ?>>Available</option>
                        <option value="occupied" <?= $t['status']=='occupied'?'selected':'' ?>>Occupied</option>
                        <option value="reserved" <?= $t['status']=='reserved'?'selected':'' ?>>Reserved</option>
                    </select>
                </form>
                <a class="btn btn-danger btn-sm" href="ajax/tables.php?action=delete&id=<?= $t['table_id'] ?>" data-confirm="Delete this table?">Delete</a>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="modal-backdrop" id="tableModal">
    <div class="modal">
        <div class="modal-header"><h3 class="mt-0">Add Table</h3><button class="modal-close" onclick="closeModal('tableModal')">&times;</button></div>
        <form action="ajax/tables.php?action=add" method="POST">
            <label>Table Number / Name</label>
            <input type="text" name="table_number" placeholder="e.g. T7" required>
            <label>Seating Capacity</label>
            <input type="number" name="capacity" min="1" value="4" required>
            <button type="submit" class="btn btn-primary btn-block">Add Table</button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
