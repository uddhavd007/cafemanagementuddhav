<?php
require_once __DIR__ . '/../../config/config.php';
require_role('admin');

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'add':
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $pass  = $_POST['password'] ?? '';

        if ($name === '' || $email === '' || strlen($pass) < 6) {
            flash('error', 'Please fill all required fields (password min 6 characters).');
            redirect('admin/staff.php');
        }

        $check = $pdo->prepare('SELECT user_id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            flash('error', 'A user with that email already exists.');
            redirect('admin/staff.php');
        }

        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, "staff")');
        $stmt->execute([$name, $email, $hash, $phone]);
        flash('success', 'Staff member added.');
        redirect('admin/staff.php');
        break;

    case 'toggle_status':
        $id = (int) ($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE users SET status = IF(status='active','inactive','active') WHERE user_id = ? AND role = 'staff'");
        $stmt->execute([$id]);
        flash('success', 'Staff status updated.');
        redirect('admin/staff.php');
        break;

    case 'delete':
        $id = (int) ($_GET['id'] ?? 0);
        $pdo->prepare("DELETE FROM users WHERE user_id = ? AND role = 'staff'")->execute([$id]);
        flash('success', 'Staff member removed.');
        redirect('admin/staff.php');
        break;

    default:
        redirect('admin/staff.php');
}
