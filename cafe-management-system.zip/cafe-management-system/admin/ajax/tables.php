<?php
require_once __DIR__ . '/../../config/config.php';
require_role('admin');

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'add':
        $num = trim($_POST['table_number'] ?? '');
        $cap = (int) ($_POST['capacity'] ?? 2);
        if ($num === '') { flash('error', 'Table number is required.'); redirect('admin/tables.php'); }
        $stmt = $pdo->prepare('INSERT INTO cafe_tables (table_number, capacity) VALUES (?, ?)');
        $stmt->execute([$num, $cap]);
        flash('success', 'Table added.');
        redirect('admin/tables.php');
        break;

    case 'set_status':
        $id = (int) ($_POST['table_id'] ?? 0);
        $status = $_POST['status'] ?? 'available';
        if (!in_array($status, ['available','occupied','reserved'], true)) $status = 'available';
        $pdo->prepare('UPDATE cafe_tables SET status = ? WHERE table_id = ?')->execute([$status, $id]);
        flash('success', 'Table status updated.');
        redirect('admin/tables.php');
        break;

    case 'delete':
        $id = (int) ($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM cafe_tables WHERE table_id = ?')->execute([$id]);
        flash('success', 'Table deleted.');
        redirect('admin/tables.php');
        break;

    default:
        redirect('admin/tables.php');
}
