<?php
require_once __DIR__ . '/../../config/config.php';
require_role('admin');

$action = $_GET['action'] ?? '';
$orderId = (int) ($_POST['order_id'] ?? 0);

switch ($action) {

    case 'update_status':
        $status = $_POST['status'] ?? 'pending';
        $valid = ['pending','preparing','ready','served','completed','cancelled'];
        if (!in_array($status, $valid, true)) $status = 'pending';
        $pdo->prepare('UPDATE orders SET status = ? WHERE order_id = ?')->execute([$status, $orderId]);

        // free up the table automatically when an order is completed/cancelled
        if (in_array($status, ['completed', 'cancelled'], true)) {
            $o = $pdo->prepare('SELECT table_id FROM orders WHERE order_id = ?');
            $o->execute([$orderId]);
            $tableId = $o->fetchColumn();
            if ($tableId) {
                $pdo->prepare("UPDATE cafe_tables SET status = 'available' WHERE table_id = ?")->execute([$tableId]);
            }
        }
        flash('success', 'Order status updated.');
        redirect('admin/order_details.php?id=' . $orderId);
        break;

    case 'update_payment':
        $payStatus = $_POST['payment_status'] ?? 'unpaid';
        $method = $_POST['payment_method'] ?? null;
        $pdo->prepare('UPDATE orders SET payment_status = ?, payment_method = ? WHERE order_id = ?')
            ->execute([$payStatus, $method, $orderId]);
        flash('success', 'Payment info updated.');
        redirect('admin/order_details.php?id=' . $orderId);
        break;

    default:
        redirect('admin/orders.php');
}
