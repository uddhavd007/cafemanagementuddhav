<?php
require_once __DIR__ . '/../../config/config.php';
require_role('admin');

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'add_category':
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        if ($name === '') { flash('error', 'Category name is required.'); redirect('admin/menu.php'); }
        $stmt = $pdo->prepare('INSERT INTO categories (name, description) VALUES (?, ?)');
        $stmt->execute([$name, $desc]);
        flash('success', 'Category added.');
        redirect('admin/menu.php');
        break;

    case 'delete_category':
        $id = (int) ($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM categories WHERE category_id = ?')->execute([$id]);
        flash('success', 'Category deleted.');
        redirect('admin/menu.php');
        break;

    case 'save_item':
        $itemId   = (int) ($_POST['item_id'] ?? 0);
        $name     = trim($_POST['name'] ?? '');
        $catId    = (int) ($_POST['category_id'] ?? 0);
        $desc     = trim($_POST['description'] ?? '');
        $price    = (float) ($_POST['price'] ?? 0);
        $avail    = (int) ($_POST['is_available'] ?? 1);

        if ($name === '' || $catId <= 0 || $price <= 0) {
            flash('error', 'Please fill in all required item fields.');
            redirect('admin/menu.php');
        }

        if ($itemId > 0) {
            $stmt = $pdo->prepare('UPDATE menu_items SET name=?, category_id=?, description=?, price=?, is_available=? WHERE item_id=?');
            $stmt->execute([$name, $catId, $desc, $price, $avail, $itemId]);
            flash('success', 'Menu item updated.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO menu_items (name, category_id, description, price, is_available) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$name, $catId, $desc, $price, $avail]);
            flash('success', 'Menu item added.');
        }
        redirect('admin/menu.php');
        break;

    case 'delete_item':
        $id = (int) ($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM menu_items WHERE item_id = ?')->execute([$id]);
        flash('success', 'Menu item deleted.');
        redirect('admin/menu.php');
        break;

    default:
        redirect('admin/menu.php');
}
