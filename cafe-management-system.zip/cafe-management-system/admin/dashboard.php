<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$pageTitle = 'Dashboard';
$pageSubtitle = 'Overview of today\'s cafe activity';

// Today's stats
$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT COUNT(*) c, COALESCE(SUM(grand_total),0) s FROM orders WHERE DATE(created_at) = ? AND status != 'cancelled'");
$stmt->execute([$today]);
$todayStats = $stmt->fetch();

$pendingCount = $pdo->query("SELECT COUNT(*) c FROM orders WHERE status IN ('pending','preparing')")->fetch()['c'];
$occupiedTables = $pdo->query("SELECT COUNT(*) c FROM cafe_tables WHERE status = 'occupied'")->fetch()['c'];
$totalTables = $pdo->query("SELECT COUNT(*) c FROM cafe_tables")->fetch()['c'];
$totalStaff = $pdo->query("SELECT COUNT(*) c FROM users WHERE role = 'staff' AND status = 'active'")->fetch()['c'];

$recentOrders = $pdo->query("
    SELECT o.*, t.table_number
    FROM orders o LEFT JOIN cafe_tables t ON o.table_id = t.table_id
    ORDER BY o.created_at DESC LIMIT 8
")->fetchAll();

$topItems = $pdo->query("
    SELECT item_name, SUM(quantity) qty
    FROM order_items oi JOIN orders o ON oi.order_id = o.order_id
    WHERE o.status != 'cancelled'
    GROUP BY item_name ORDER BY qty DESC LIMIT 5
")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="grid grid-4">
    <div class="card stat-card">
        <div class="stat-label">Today's Revenue</div>
        <div class="stat-value"><?= format_price($todayStats['s']) ?></div>
        <div class="stat-sub"><?= (int)$todayStats['c'] ?> orders today</div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Active Orders</div>
        <div class="stat-value"><?= (int)$pendingCount ?></div>
        <div class="stat-sub">pending / preparing</div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Tables Occupied</div>
        <div class="stat-value"><?= (int)$occupiedTables ?>/<?= (int)$totalTables ?></div>
        <div class="stat-sub">currently in use</div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Active Staff</div>
        <div class="stat-value"><?= (int)$totalStaff ?></div>
        <div class="stat-sub">on the roster</div>
    </div>
</div>

<div class="grid grid-2" style="margin-top:22px; align-items:start;">
    <div class="card">
        <h3>Recent Orders</h3>
        <table class="data-table" style="margin-top:10px;">
            <thead><tr><th>Order #</th><th>Table</th><th>Status</th><th>Total</th><th></th></tr></thead>
            <tbody>
            <?php if (!$recentOrders): ?>
                <tr><td colspan="5" class="muted">No orders yet.</td></tr>
            <?php endif; ?>
            <?php foreach ($recentOrders as $o): ?>
                <tr>
                    <td class="gold" style="font-family: var(--font-mono); font-size:12.5px;"><?= clean($o['order_number']) ?></td>
                    <td><?= $o['table_number'] ? clean($o['table_number']) : ucfirst($o['order_type']) ?></td>
                    <td><span class="badge <?= status_badge_class($o['status']) ?>"><?= clean($o['status']) ?></span></td>
                    <td><?= format_price($o['grand_total']) ?></td>
                    <td><a class="btn btn-outline btn-sm" href="order_details.php?id=<?= $o['order_id'] ?>">View</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h3>Top Selling Items</h3>
        <table class="data-table" style="margin-top:10px;">
            <thead><tr><th>Item</th><th>Qty Sold</th></tr></thead>
            <tbody>
            <?php if (!$topItems): ?>
                <tr><td colspan="2" class="muted">No sales data yet.</td></tr>
            <?php endif; ?>
            <?php foreach ($topItems as $t): ?>
                <tr><td><?= clean($t['item_name']) ?></td><td class="gold"><?= (int)$t['qty'] ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
