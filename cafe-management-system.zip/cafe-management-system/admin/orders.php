<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$pageTitle = 'Orders';
$pageSubtitle = 'All customer & dine-in orders';

$filter = $_GET['status'] ?? '';
$sql = "SELECT o.*, t.table_number, u.name AS staff_name
        FROM orders o
        LEFT JOIN cafe_tables t ON o.table_id = t.table_id
        LEFT JOIN users u ON o.staff_id = u.user_id";
$params = [];
if ($filter !== '') {
    $sql .= " WHERE o.status = ?";
    $params[] = $filter;
}
$sql .= " ORDER BY o.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="card" style="margin-bottom:18px;">
    <div class="flex gap-8" style="flex-wrap:wrap;">
        <a class="btn btn-sm <?= $filter===''?'btn-primary':'btn-outline' ?>" href="orders.php">All</a>
        <?php foreach (['pending','preparing','ready','served','completed','cancelled'] as $s): ?>
            <a class="btn btn-sm <?= $filter===$s?'btn-primary':'btn-outline' ?>" href="orders.php?status=<?= $s ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
    </div>
</div>

<div class="card">
    <table class="data-table">
        <thead><tr><th>Order #</th><th>Type</th><th>Table</th><th>Staff</th><th>Status</th><th>Payment</th><th>Total</th><th>Time</th><th></th></tr></thead>
        <tbody>
        <?php if (!$orders): ?><tr><td colspan="9" class="muted">No orders found.</td></tr><?php endif; ?>
        <?php foreach ($orders as $o): ?>
            <tr>
                <td style="font-family:var(--font-mono); font-size:12.5px;" class="gold"><?= clean($o['order_number']) ?></td>
                <td><?= ucfirst(str_replace('_',' ',$o['order_type'])) ?></td>
                <td><?= $o['table_number'] ? clean($o['table_number']) : '—' ?></td>
                <td><?= $o['staff_name'] ? clean($o['staff_name']) : '—' ?></td>
                <td><span class="badge <?= status_badge_class($o['status']) ?>"><?= clean($o['status']) ?></span></td>
                <td><span class="badge <?= status_badge_class($o['payment_status']) ?>"><?= clean($o['payment_status']) ?></span></td>
                <td><?= format_price($o['grand_total']) ?></td>
                <td class="muted" style="font-size:12px;"><?= date('d M, h:i A', strtotime($o['created_at'])) ?></td>
                <td><a class="btn btn-outline btn-sm" href="order_details.php?id=<?= $o['order_id'] ?>">View</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
