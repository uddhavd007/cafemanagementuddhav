<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$pageTitle = 'Menu Management';
$pageSubtitle = 'Add, edit and manage menu items & categories';
$topbarActions = '<button class="btn btn-outline" onclick="openModal(\'categoryModal\')">+ Category</button> <button class="btn btn-primary" onclick="openModal(\'itemModal\')">+ Menu Item</button>';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$items = $pdo->query("
    SELECT mi.*, c.name AS category_name
    FROM menu_items mi JOIN categories c ON mi.category_id = c.category_id
    ORDER BY c.name, mi.name
")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <table class="data-table">
        <thead><tr><th>Item</th><th>Category</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (!$items): ?><tr><td colspan="5" class="muted">No menu items yet — add your first one.</td></tr><?php endif; ?>
        <?php foreach ($items as $it): ?>
            <tr>
                <td><?= clean($it['name']) ?><br><span class="muted" style="font-size:12px;"><?= clean($it['description']) ?></span></td>
                <td><?= clean($it['category_name']) ?></td>
                <td class="gold"><?= format_price($it['price']) ?></td>
                <td><span class="badge <?= $it['is_available'] ? 'badge-available' : 'badge-cancelled' ?>"><?= $it['is_available'] ? 'Available' : 'Unavailable' ?></span></td>
                <td class="flex gap-8">
                    <button class="btn btn-outline btn-sm" onclick='editItem(<?= json_encode($it, JSON_HEX_APOS) ?>)'>Edit</button>
                    <a class="btn btn-danger btn-sm" href="ajax/menu.php?action=delete_item&id=<?= $it['item_id'] ?>" data-confirm="Delete this menu item?">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="card" style="margin-top:20px;">
    <h3>Categories</h3>
    <table class="data-table" style="margin-top:10px;">
        <thead><tr><th>Name</th><th>Description</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($categories as $c): ?>
            <tr>
                <td><?= clean($c['name']) ?></td>
                <td class="muted"><?= clean($c['description']) ?></td>
                <td><a class="btn btn-danger btn-sm" href="ajax/menu.php?action=delete_category&id=<?= $c['category_id'] ?>" data-confirm="Delete this category and all its items?">Delete</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Category modal -->
<div class="modal-backdrop" id="categoryModal">
    <div class="modal">
        <div class="modal-header"><h3 class="mt-0">Add Category</h3><button class="modal-close" onclick="closeModal('categoryModal')">&times;</button></div>
        <form action="ajax/menu.php?action=add_category" method="POST">
            <label>Category Name</label>
            <input type="text" name="name" required>
            <label>Description</label>
            <textarea name="description" rows="2"></textarea>
            <button type="submit" class="btn btn-primary btn-block">Save Category</button>
        </form>
    </div>
</div>

<!-- Item add/edit modal -->
<div class="modal-backdrop" id="itemModal">
    <div class="modal">
        <div class="modal-header"><h3 class="mt-0" id="itemModalTitle">Add Menu Item</h3><button class="modal-close" onclick="closeModal('itemModal')">&times;</button></div>
        <form action="ajax/menu.php?action=save_item" method="POST" id="itemForm">
            <input type="hidden" name="item_id" id="f_item_id">
            <label>Item Name</label>
            <input type="text" name="name" id="f_name" required>
            <label>Category</label>
            <select name="category_id" id="f_category" required>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= $c['category_id'] ?>"><?= clean($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <label>Description</label>
            <textarea name="description" id="f_description" rows="2"></textarea>
            <div class="form-row">
                <div>
                    <label>Price (<?= CURRENCY ?>)</label>
                    <input type="number" step="0.01" min="0" name="price" id="f_price" required>
                </div>
                <div>
                    <label>Availability</label>
                    <select name="is_available" id="f_available">
                        <option value="1">Available</option>
                        <option value="0">Unavailable</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Save Item</button>
        </form>
    </div>
</div>

<?php
$extraScripts = '<script>
function editItem(it) {
    document.getElementById("itemModalTitle").textContent = "Edit Menu Item";
    document.getElementById("f_item_id").value = it.item_id;
    document.getElementById("f_name").value = it.name;
    document.getElementById("f_category").value = it.category_id;
    document.getElementById("f_description").value = it.description || "";
    document.getElementById("f_price").value = it.price;
    document.getElementById("f_available").value = it.is_available;
    openModal("itemModal");
}
</script>';
include __DIR__ . '/../includes/footer.php';
?>
