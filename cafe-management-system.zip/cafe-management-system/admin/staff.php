<?php
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$pageTitle = 'Staff Management';
$pageSubtitle = 'Manage staff accounts and access';
$topbarActions = '<button class="btn btn-primary" onclick="openModal(\'staffModal\')">+ Add Staff</button>';

$staff = $pdo->query("SELECT * FROM users WHERE role = 'staff' ORDER BY created_at DESC")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <table class="data-table">
        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (!$staff): ?><tr><td colspan="6" class="muted">No staff added yet.</td></tr><?php endif; ?>
        <?php foreach ($staff as $s): ?>
            <tr>
                <td><?= clean($s['name']) ?></td>
                <td><?= clean($s['email']) ?></td>
                <td><?= clean($s['phone']) ?></td>
                <td><span class="badge <?= status_badge_class($s['status']) ?>"><?= clean($s['status']) ?></span></td>
                <td class="muted"><?= date('d M Y', strtotime($s['created_at'])) ?></td>
                <td class="flex gap-8">
                    <a class="btn btn-outline btn-sm" href="ajax/staff.php?action=toggle_status&id=<?= $s['user_id'] ?>">
                        <?= $s['status'] === 'active' ? 'Deactivate' : 'Activate' ?>
                    </a>
                    <a class="btn btn-danger btn-sm" href="ajax/staff.php?action=delete&id=<?= $s['user_id'] ?>" data-confirm="Remove this staff member?">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="modal-backdrop" id="staffModal">
    <div class="modal">
        <div class="modal-header"><h3 class="mt-0">Add Staff Member</h3><button class="modal-close" onclick="closeModal('staffModal')">&times;</button></div>
        <form action="ajax/staff.php?action=add" method="POST">
            <label>Full Name</label>
            <input type="text" name="name" required>
            <label>Email</label>
            <input type="email" name="email" required>
            <label>Phone</label>
            <input type="text" name="phone">
            <label>Temporary Password</label>
            <input type="password" name="password" required minlength="6">
            <button type="submit" class="btn btn-primary btn-block">Add Staff</button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
