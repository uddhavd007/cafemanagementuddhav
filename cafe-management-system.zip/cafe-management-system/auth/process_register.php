<?php
require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('auth/register.php');

$name     = trim($_POST['name'] ?? '');
$email    = trim($_POST['email'] ?? '');
$phone    = trim($_POST['phone'] ?? '');
$password = $_POST['password'] ?? '';
$confirm  = $_POST['password_confirm'] ?? '';

$_SESSION['old'] = ['name' => $name, 'email' => $email, 'phone' => $phone];

if ($name === '' || $email === '' || $password === '') {
    flash('error', 'Please fill in all required fields.');
    redirect('auth/register.php');
}
if (strlen($password) < 6) {
    flash('error', 'Password must be at least 6 characters.');
    redirect('auth/register.php');
}
if ($password !== $confirm) {
    flash('error', 'Passwords do not match.');
    redirect('auth/register.php');
}

$stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) {
    flash('error', 'An account with that email already exists.');
    redirect('auth/register.php');
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, "customer")');
$stmt->execute([$name, $email, $hash, $phone]);

unset($_SESSION['old']);
$_SESSION['user_id'] = $pdo->lastInsertId();
$_SESSION['name']    = $name;
$_SESSION['role']    = 'customer';

flash('success', 'Welcome to Brew & Bean, ' . $name . '!');
redirect('customer/menu.php');
