<?php
require_once __DIR__ . '/../config/config.php';
if (is_logged_in()) redirect('index.php');
$err = flash('error');
$old = $_SESSION['old'] ?? [];
unset($_SESSION['old']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create account – <?= SITE_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="brand">☕ Brew & Bean</div>
        <div class="tagline">Create your customer account</div>
        <?php if ($err): ?><div class="alert alert-error">⚠ <?= clean($err) ?></div><?php endif; ?>
        <form action="process_register.php" method="POST">
            <label>Full Name</label>
            <input type="text" name="name" value="<?= clean($old['name'] ?? '') ?>" required autofocus>
            <label>Email</label>
            <input type="email" name="email" value="<?= clean($old['email'] ?? '') ?>" required>
            <label>Phone</label>
            <input type="text" name="phone" value="<?= clean($old['phone'] ?? '') ?>">
            <label>Password</label>
            <input type="password" name="password" required minlength="6">
            <label>Confirm Password</label>
            <input type="password" name="password_confirm" required minlength="6">
            <button type="submit" class="btn btn-primary btn-block">Create account</button>
        </form>
        <div class="auth-switch">Already have an account? <a href="login.php">Log in</a></div>
    </div>
</div>
</body>
</html>
