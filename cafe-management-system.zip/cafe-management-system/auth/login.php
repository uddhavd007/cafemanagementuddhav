<?php
require_once __DIR__ . '/../config/config.php';
if (is_logged_in()) redirect('index.php');
$err = flash('error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Log in – <?= SITE_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="brand">☕ Brew & Bean</div>
        <div class="tagline">Sign in to your account</div>
        <?php if ($err): ?><div class="alert alert-error">⚠ <?= clean($err) ?></div><?php endif; ?>
        <form action="process_login.php" method="POST">
            <label>Email</label>
            <input type="email" name="email" required autofocus>
            <label>Password</label>
            <input type="password" name="password" required>
            <button type="submit" class="btn btn-primary btn-block">Log in</button>
        </form>
        <div class="auth-switch">New here? <a href="register.php">Create a customer account</a></div>
        <div class="auth-switch" style="margin-top:18px; font-size:12px;">
            Demo logins — Admin: admin@brewbean.com / admin123 &nbsp;|&nbsp; Staff: staff@brewbean.com / staff123
        </div>
    </div>
</div>
</body>
</html>
