<?php
require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('auth/login.php');

$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if ($email === '' || $password === '') {
    flash('error', 'Please enter both email and password.');
    redirect('auth/login.php');
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    flash('error', 'Invalid email or password.');
    redirect('auth/login.php');
}

if ($user['status'] !== 'active') {
    flash('error', 'Your account has been deactivated. Contact the cafe admin.');
    redirect('auth/login.php');
}

$_SESSION['user_id'] = $user['user_id'];
$_SESSION['name']    = $user['name'];
$_SESSION['role']    = $user['role'];

switch ($user['role']) {
    case 'admin': redirect('admin/dashboard.php');
    case 'staff': redirect('staff/dashboard.php');
    default:      redirect('customer/menu.php');
}
