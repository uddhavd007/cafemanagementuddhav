# Brew & Bean — Cafe Management System

A full-stack mini project: **PHP + MySQL** backend, **HTML/CSS/JavaScript** frontend.
Three roles — **Admin**, **Staff**, and **Customer** — each with their own dashboard.

## Features

**Admin**
- Dashboard with today's revenue, active orders, table occupancy, staff count
- Menu management — categories + items (add/edit/delete, availability toggle)
- Staff management — add staff accounts, activate/deactivate, delete
- Table management — add tables, set capacity, update status
- Orders — view all orders, filter by status, update status & payment
- Reports — sales chart (Chart.js), top-selling items, average order value

**Staff**
- Dashboard — live order queue, table overview, today's order count
- Take Order — pick a table or takeaway, build an order from the menu, live totals
- Order queue — progress orders through pending → preparing → ready → served → completed
- Billing — generate a bill/invoice for unpaid orders, record payment method, print
- Tables — update table status (available / occupied / reserved)

**Customer**
- Public menu (storefront) — browse by category
- Register / log in
- Cart — add items, adjust quantity, choose dine-in table or takeaway
- Checkout — places the order, auto-computes tax
- Order history + printable invoice/ticket per order

## Tech Stack
- **Frontend:** HTML5, CSS3 (custom dark "espresso" dashboard theme, no framework), vanilla JavaScript
- **Backend:** PHP (PDO, prepared statements)
- **Database:** MySQL / MariaDB
- **Charts:** Chart.js (via CDN)

## Setup (XAMPP / WAMP / LAMP)

1. **Copy the project** into your server's web root, e.g. `htdocs/cafe-management-system`.

2. **Create the database.**
   - Open phpMyAdmin (or the `mysql` CLI).
   - Import `database/schema.sql`. This creates the `cafe_management` database, all tables, and seed data.

   ```bash
   mysql -u root -p < database/schema.sql
   ```

3. **Configure the DB connection.**
   Open `config/database.php` and update if your MySQL user/password differ from the defaults:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'cafe_management');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

4. **Start your server** (Apache via XAMPP/WAMP, or `php -S localhost:8000` from the project root) and visit:
   ```
   http://localhost/cafe-management-system/
   ```

## Demo Logins

| Role     | Email                     | Password    |
|----------|---------------------------|-------------|
| Admin    | admin@brewbean.com        | admin123    |
| Staff    | staff@brewbean.com        | staff123    |
| Customer | customer@brewbean.com     | customer123 |

(Or register a new customer account from the login page.)

## Project Structure

```
cafe-management-system/
├── admin/                # Admin pages + admin/ajax/ handlers
├── staff/                # Staff pages + staff/ajax/ handlers
├── customer/             # Public menu, cart, orders + customer/ajax/ handlers
├── auth/                 # login, register, logout
├── config/                # database.php, config.php
├── includes/              # shared header/footer/sidebar/functions
├── assets/
│   ├── css/style.css      # single stylesheet, dark dashboard theme
│   └── js/                 # main.js, staff.js (order builder)
├── database/schema.sql     # full schema + seed data
└── index.php               # role-based redirect
```

## Notes for your mini-project report
- **Authentication:** passwords hashed with bcrypt (`password_hash` / `password_verify`), PHP sessions for login state.
- **Security:** all database queries use PDO prepared statements; all output is escaped with `htmlspecialchars` via the `clean()` helper.
- **Order flow:** an order automatically marks its table `occupied`; marking the order `completed` or `cancelled` frees the table again.
- **Tax:** a flat rate is applied to every order, configurable in `config/config.php` (`TAX_RATE`).
- **Currency:** defaults to ₹ (Indian Rupee), configurable in `config/config.php` (`CURRENCY`).

## Extending it further
- Add email/SMS order notifications
- Add a kitchen display screen (auto-refreshing `staff/orders.php`)
- Add PDF invoice export
- Add sales reports by date range / export to CSV
