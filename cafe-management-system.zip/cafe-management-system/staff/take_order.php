<?php
require_once __DIR__ . '/../config/config.php';
require_role('staff');

$pageTitle = 'Take Order';
$pageSubtitle = 'Build a new order for a table or takeaway';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$items = $pdo->query("SELECT * FROM menu_items WHERE is_available = 1 ORDER BY category_id, name")->fetchAll();
$tables = $pdo->query("SELECT * FROM cafe_tables WHERE status != 'occupied' ORDER BY table_number")->fetchAll();

$itemsByCat = [];
foreach ($items as $it) { $itemsByCat[$it['category_id']][] = $it; }

include __DIR__ . '/../includes/header.php';
?>

<div class="grid" style="grid-template-columns: 2fr 1fr; align-items:start; gap:20px;">
    <div>
        <?php foreach ($categories as $c): if (empty($itemsByCat[$c['category_id']])) continue; ?>
            <h3 class="menu-cat-title"><?= clean($c['name']) ?></h3>
            <div class="menu-grid">
                <?php foreach ($itemsByCat[$c['category_id']] as $it): ?>
                    <div class="menu-card" data-item-id="<?= $it['item_id'] ?>" data-name="<?= clean($it['name']) ?>" data-price="<?= $it['price'] ?>">
                        <div class="m-name"><?= clean($it['name']) ?></div>
                        <div class="m-desc"><?= clean($it['description']) ?></div>
                        <div class="m-footer">
                            <span class="m-price"><?= format_price($it['price']) ?></span>
                            <button type="button" class="btn btn-outline btn-sm add-to-order">+ Add</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card" style="position:sticky; top:20px;">
        <h3 class="mt-0">Current Order</h3>
        <label>Order Type</label>
        <select id="orderType">
            <option value="dine_in">Dine-in</option>
            <option value="takeaway">Takeaway</option>
        </select>
        <div id="tableSelectWrap">
            <label>Table</label>
            <select id="tableSelect">
                <option value="">Select a table…</option>
                <?php foreach ($tables as $t): ?>
                    <option value="<?= $t['table_id'] ?>"><?= clean($t['table_number']) ?> (seats <?= (int)$t['capacity'] ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>

        <div id="orderCart" style="margin:14px 0; min-height:40px;">
            <p class="muted" id="emptyCartMsg">No items added yet.</p>
        </div>

        <div class="ti-row"><span class="muted">Subtotal</span><span id="cartSubtotal"><?= format_price(0) ?></span></div>
        <div class="ti-row"><span class="muted">Tax (<?= TAX_RATE*100 ?>%)</span><span id="cartTax"><?= format_price(0) ?></span></div>
        <div class="ticket-total" style="margin-top:8px;"><span>Total</span><span id="cartTotal"><?= format_price(0) ?></span></div>

        <label style="margin-top:14px;">Notes (optional)</label>
        <textarea id="orderNotes" rows="2" placeholder="e.g. less sugar"></textarea>

        <button class="btn btn-primary btn-block" id="placeOrderBtn" disabled>Place Order</button>
    </div>
</div>

<?php
$extraScripts = '<script>
const TAX_RATE = ' . TAX_RATE . ';
const CURRENCY = "' . CURRENCY . '";
const AJAX_URL = "' . BASE_URL . 'staff/ajax/orders.php?action=create";
</script>
<script src="' . BASE_URL . 'assets/js/staff.js"></script>';
include __DIR__ . '/../includes/footer.php';
?>
