<?php
require_once __DIR__ . '/../config/config.php';
require_role('staff');

$pageTitle = 'Orders Queue';
$pageSubtitle = 'Update order status as items are prepared and served';

$orders = $pdo->query("
    SELECT o.*, t.table_number
    FROM orders o LEFT JOIN cafe_tables t ON o.table_id = t.table_id
    WHERE o.status NOT IN ('completed','cancelled')
    ORDER BY o.created_at ASC
")->fetchAll();

$nextStatus = ['pending' => 'preparing', 'preparing' => 'ready', 'ready' => 'served', 'served' => 'completed'];

include __DIR__ . '/../includes/header.php';
?>

<div class="grid grid-3">
    <?php if (!$orders): ?>
        <div class="empty-state" style="grid-column: 1/-1;">
            <div class="icon">🧾</div>
            <p>No active orders. <a href="take_order.php" class="gold">Take a new order</a></p>
        </div>
    <?php endif; ?>
    <?php foreach ($orders as $o):
        $items = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $items->execute([$o['order_id']]);
        $items = $items->fetchAll();
    ?>
        <div class="ticket">
            <div class="ticket-head">
                <div>
                    <div class="t-num"><?= clean($o['order_number']) ?></div>
                    <div class="t-meta"><?= $o['table_number'] ? 'Table ' . clean($o['table_number']) : ucfirst($o['order_type']) ?> · <?= date('h:i A', strtotime($o['created_at'])) ?></div>
                </div>
                <span class="badge <?= status_badge_class($o['status']) ?>"><?= clean($o['status']) ?></span>
            </div>
            <div class="ticket-items">
                <?php foreach ($items as $it): ?>
                    <div class="ti-row"><span class="ti-name"><?= clean($it['item_name']) ?></span><span class="ti-qty">× <?= (int)$it['quantity'] ?></span></div>
                <?php endforeach; ?>
            </div>
            <div class="ticket-total"><span>Total</span><span><?= format_price($o['grand_total']) ?></span></div>
            <div class="ticket-foot" style="gap:8px;">
                <?php if (isset($nextStatus[$o['status']])): ?>
                    <form action="ajax/orders.php?action=update_status" method="POST" style="flex:1;">
                        <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                        <input type="hidden" name="status" value="<?= $nextStatus[$o['status']] ?>">
                        <button class="btn btn-sage btn-block btn-sm">Mark as <?= ucfirst($nextStatus[$o['status']]) ?></button>
                    </form>
                <?php endif; ?>
                <form action="ajax/orders.php?action=update_status" method="POST">
                    <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                    <input type="hidden" name="status" value="cancelled">
                    <button class="btn btn-danger btn-sm" data-confirm="Cancel this order?">Cancel</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
