<?php
require_once __DIR__ . '/../config/config.php';
require_role('staff');

$pageTitle = 'Tables';
$pageSubtitle = 'View and update table status';

$tables = $pdo->query("SELECT * FROM cafe_tables ORDER BY table_number")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="grid grid-4">
    <?php foreach ($tables as $t): ?>
        <div class="card">
            <div class="flex-between">
                <h3 class="mt-0"><?= clean($t['table_number']) ?></h3>
                <span class="badge <?= status_badge_class($t['status']) ?>"><?= clean($t['status']) ?></span>
            </div>
            <p style="margin:4px 0 14px;">Seats <?= (int)$t['capacity'] ?></p>
            <form action="ajax/tables.php?action=set_status" method="POST">
                <input type="hidden" name="table_id" value="<?= $t['table_id'] ?>">
                <select name="status" onchange="this.form.submit()" style="margin-bottom:0;">
                    <option value="available" <?= $t['status']=='available'?'selected':'' ?>>Available</option>
                    <option value="occupied" <?= $t['status']=='occupied'?'selected':'' ?>>Occupied</option>
                    <option value="reserved" <?= $t['status']=='reserved'?'selected':'' ?>>Reserved</option>
                </select>
            </form>
        </div>
    <?php endforeach; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
