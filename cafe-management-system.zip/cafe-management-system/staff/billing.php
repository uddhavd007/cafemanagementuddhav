<?php
require_once __DIR__ . '/../config/config.php';
require_role('staff');

$pageTitle = 'Billing';
$pageSubtitle = 'Generate bills for served orders';

$selectedId = (int) ($_GET['id'] ?? 0);

$unpaidOrders = $pdo->query("
    SELECT o.*, t.table_number FROM orders o
    LEFT JOIN cafe_tables t ON o.table_id = t.table_id
    WHERE o.payment_status = 'unpaid' AND o.status != 'cancelled'
    ORDER BY o.created_at ASC
")->fetchAll();

$order = null; $items = [];
if ($selectedId) {
    $stmt = $pdo->prepare("SELECT o.*, t.table_number FROM orders o LEFT JOIN cafe_tables t ON o.table_id = t.table_id WHERE o.order_id = ?");
    $stmt->execute([$selectedId]);
    $order = $stmt->fetch();
    if ($order) {
        $itemStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $itemStmt->execute([$selectedId]);
        $items = $itemStmt->fetchAll();
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="grid" style="grid-template-columns: 1fr 1.2fr; align-items:start; gap:20px;">
    <div class="card">
        <h3 class="mt-0">Unpaid Orders</h3>
        <table class="data-table" style="margin-top:10px;">
            <thead><tr><th>Order #</th><th>Table</th><th>Total</th><th></th></tr></thead>
            <tbody>
            <?php if (!$unpaidOrders): ?><tr><td colspan="4" class="muted">All caught up — no unpaid orders.</td></tr><?php endif; ?>
            <?php foreach ($unpaidOrders as $o): ?>
                <tr class="<?= $selectedId==$o['order_id']?'active':'' ?>">
                    <td class="gold" style="font-family:var(--font-mono); font-size:12.5px;"><?= clean($o['order_number']) ?></td>
                    <td><?= $o['table_number'] ? clean($o['table_number']) : ucfirst($o['order_type']) ?></td>
                    <td><?= format_price($o['grand_total']) ?></td>
                    <td><a class="btn btn-outline btn-sm" href="billing.php?id=<?= $o['order_id'] ?>">Bill</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div>
        <?php if ($order): ?>
            <div class="ticket" id="printArea">
                <div class="ticket-head">
                    <div>
                        <div class="t-num"><?= clean($order['order_number']) ?></div>
                        <div class="t-meta"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></div>
                    </div>
                    <span class="badge <?= status_badge_class($order['status']) ?>"><?= clean($order['status']) ?></span>
                </div>
                <p class="muted" style="margin:0;"><?= $order['table_number'] ? 'Table ' . clean($order['table_number']) : ucfirst(str_replace('_',' ',$order['order_type'])) ?></p>
                <div class="ticket-items">
                    <?php foreach ($items as $it): ?>
                        <div class="ti-row">
                            <span class="ti-name"><?= clean($it['item_name']) ?> <span class="ti-qty">× <?= (int)$it['quantity'] ?></span></span>
                            <span><?= format_price($it['subtotal']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="ti-row"><span class="muted">Subtotal</span><span><?= format_price($order['subtotal']) ?></span></div>
                <div class="ti-row"><span class="muted">Tax</span><span><?= format_price($order['tax_amount']) ?></span></div>
                <div class="ticket-total" style="margin-top:8px;"><span>Total Due</span><span><?= format_price($order['grand_total']) ?></span></div>
            </div>

            <div class="card" style="margin-top:16px;">
                <form action="ajax/orders.php?action=mark_paid" method="POST">
                    <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                    <label>Payment Method</label>
                    <select name="payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="card">Card</option>
                        <option value="upi">UPI</option>
                    </select>
                    <div class="flex gap-8">
                        <button type="submit" class="btn btn-sage btn-block">Mark as Paid</button>
                        <button type="button" class="btn btn-outline" onclick="window.print()">Print</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="empty-state"><div class="icon">💳</div><p>Select an unpaid order to generate its bill.</p></div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
