<?php
require_once __DIR__ . '/../config/config.php';
require_role('staff');

$pageTitle = 'Dashboard';
$pageSubtitle = 'Welcome back, ' . $_SESSION['name'];

$pendingCount = $pdo->query("SELECT COUNT(*) c FROM orders WHERE status IN ('pending','preparing')")->fetch()['c'];
$readyCount = $pdo->query("SELECT COUNT(*) c FROM orders WHERE status = 'ready'")->fetch()['c'];
$myServed = $pdo->prepare("SELECT COUNT(*) c FROM orders WHERE staff_id = ? AND DATE(created_at) = CURDATE()");
$myServed->execute([$_SESSION['user_id']]);
$myServed = $myServed->fetch()['c'];

$tables = $pdo->query("SELECT * FROM cafe_tables ORDER BY table_number")->fetchAll();

$activeOrders = $pdo->query("
    SELECT o.*, t.table_number FROM orders o
    LEFT JOIN cafe_tables t ON o.table_id = t.table_id
    WHERE o.status IN ('pending','preparing','ready')
    ORDER BY o.created_at ASC
")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="grid grid-3">
    <div class="card stat-card">
        <div class="stat-label">Active Orders</div>
        <div class="stat-value"><?= (int)$pendingCount ?></div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Ready to Serve</div>
        <div class="stat-value sage"><?= (int)$readyCount ?></div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Orders Taken Today (You)</div>
        <div class="stat-value"><?= (int)$myServed ?></div>
    </div>
</div>

<div class="grid grid-2" style="margin-top:22px; align-items:start;">
    <div class="card">
        <h3 class="mt-0">Live Orders Queue</h3>
        <table class="data-table" style="margin-top:10px;">
            <thead><tr><th>Order #</th><th>Table</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php if (!$activeOrders): ?><tr><td colspan="4" class="muted">No active orders right now.</td></tr><?php endif; ?>
            <?php foreach ($activeOrders as $o): ?>
                <tr>
                    <td class="gold" style="font-family:var(--font-mono); font-size:12.5px;"><?= clean($o['order_number']) ?></td>
                    <td><?= $o['table_number'] ? clean($o['table_number']) : ucfirst($o['order_type']) ?></td>
                    <td><span class="badge <?= status_badge_class($o['status']) ?>"><?= clean($o['status']) ?></span></td>
                    <td><a class="btn btn-outline btn-sm" href="orders.php">Manage</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h3 class="mt-0">Table Status</h3>
        <div class="grid grid-2" style="margin-top:10px;">
            <?php foreach ($tables as $t): ?>
                <div class="card" style="padding:12px;">
                    <div class="flex-between">
                        <strong><?= clean($t['table_number']) ?></strong>
                        <span class="badge <?= status_badge_class($t['status']) ?>"><?= clean($t['status']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
