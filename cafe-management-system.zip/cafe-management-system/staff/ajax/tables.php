<?php
require_once __DIR__ . '/../../config/config.php';
require_role('staff');

$action = $_GET['action'] ?? '';

if ($action === 'set_status') {
    $id = (int) ($_POST['table_id'] ?? 0);
    $status = $_POST['status'] ?? 'available';
    if (!in_array($status, ['available','occupied','reserved'], true)) $status = 'available';
    $pdo->prepare('UPDATE cafe_tables SET status = ? WHERE table_id = ?')->execute([$status, $id]);
    flash('success', 'Table status updated.');
}

redirect('staff/tables.php');
