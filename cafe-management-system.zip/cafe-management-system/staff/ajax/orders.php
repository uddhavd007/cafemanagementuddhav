<?php
require_once __DIR__ . '/../../config/config.php';
require_role('staff');

$action = $_GET['action'] ?? '';

if ($action === 'create') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) json_response(['success' => false, 'message' => 'Invalid request.'], 400);

    $orderType = $input['order_type'] === 'takeaway' ? 'takeaway' : 'dine_in';
    $tableId = $orderType === 'dine_in' ? (int) ($input['table_id'] ?? 0) : null;
    $notes = trim($input['notes'] ?? '');
    $items = $input['items'] ?? [];

    if (empty($items)) json_response(['success' => false, 'message' => 'Please add at least one item.']);
    if ($orderType === 'dine_in' && !$tableId) json_response(['success' => false, 'message' => 'Please select a table.']);

    $subtotal = 0;
    foreach ($items as $it) {
        $subtotal += (float) $it['price'] * (int) $it['quantity'];
    }
    $tax = round($subtotal * TAX_RATE, 2);
    $grandTotal = round($subtotal + $tax, 2);
    $orderNumber = generate_order_number();

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO orders
            (order_number, table_id, staff_id, order_type, status, subtotal, tax_amount, grand_total, notes)
            VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?)");
        $stmt->execute([$orderNumber, $tableId ?: null, $_SESSION['user_id'], $orderType, $subtotal, $tax, $grandTotal, $notes]);
        $orderId = $pdo->lastInsertId();

        $itemStmt = $pdo->prepare("INSERT INTO order_items (order_id, item_id, item_name, price, quantity, subtotal)
            VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($items as $it) {
            $itemStmt->execute([
                $orderId,
                (int) $it['item_id'],
                $it['name'],
                (float) $it['price'],
                (int) $it['quantity'],
                (float) $it['price'] * (int) $it['quantity'],
            ]);
        }

        if ($tableId) {
            $pdo->prepare("UPDATE cafe_tables SET status = 'occupied' WHERE table_id = ?")->execute([$tableId]);
        }

        $pdo->commit();
        json_response(['success' => true, 'redirect' => BASE_URL . 'staff/orders.php', 'order_id' => $orderId]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['success' => false, 'message' => 'Could not save order. Please try again.'], 500);
    }
}

if ($action === 'update_status') {
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? 'pending';
    $valid = ['pending','preparing','ready','served','completed','cancelled'];
    if (!in_array($status, $valid, true)) $status = 'pending';

    $pdo->prepare('UPDATE orders SET status = ? WHERE order_id = ?')->execute([$status, $orderId]);

    if (in_array($status, ['completed', 'cancelled'], true)) {
        $o = $pdo->prepare('SELECT table_id FROM orders WHERE order_id = ?');
        $o->execute([$orderId]);
        $tableId = $o->fetchColumn();
        if ($tableId) {
            $pdo->prepare("UPDATE cafe_tables SET status = 'available' WHERE table_id = ?")->execute([$tableId]);
        }
    }
    flash('success', 'Order status updated.');
    redirect('staff/orders.php');
}

if ($action === 'mark_paid') {
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $method = $_POST['payment_method'] ?? 'cash';
    $pdo->prepare("UPDATE orders SET payment_status = 'paid', payment_method = ? WHERE order_id = ?")
        ->execute([$method, $orderId]);
    flash('success', 'Payment recorded.');
    redirect('staff/billing.php');
}

redirect('staff/orders.php');
