<?php $page = basename($_SERVER['SCRIPT_NAME']); ?>
<aside class="sidebar">
    <div class="brand">☕ Brew & Bean <span>STAFF</span></div>
    <nav>
        <a href="<?= BASE_URL ?>staff/dashboard.php" class="<?= $page=='dashboard.php'?'active':'' ?>">📊 Dashboard</a>
        <a href="<?= BASE_URL ?>staff/take_order.php" class="<?= $page=='take_order.php'?'active':'' ?>">➕ Take Order</a>
        <a href="<?= BASE_URL ?>staff/orders.php" class="<?= $page=='orders.php'?'active':'' ?>">🧾 Orders</a>
        <a href="<?= BASE_URL ?>staff/billing.php" class="<?= $page=='billing.php'?'active':'' ?>">💳 Billing</a>
        <a href="<?= BASE_URL ?>staff/tables.php" class="<?= $page=='tables.php'?'active':'' ?>">🪑 Tables</a>
    </nav>
    <div class="user-box">
        <div class="u-name"><?= clean($_SESSION['name']) ?></div>
        <div class="u-role">Staff</div>
        <a class="logout-link" href="<?= BASE_URL ?>auth/logout.php">Log out →</a>
    </div>
</aside>
