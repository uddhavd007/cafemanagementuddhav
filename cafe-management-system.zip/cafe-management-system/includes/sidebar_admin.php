<?php $page = basename($_SERVER['SCRIPT_NAME']); ?>
<aside class="sidebar">
    <div class="brand">☕ Brew & Bean <span>ADMIN</span></div>
    <nav>
        <a href="<?= BASE_URL ?>admin/dashboard.php" class="<?= $page=='dashboard.php'?'active':'' ?>">📊 Dashboard</a>
        <a href="<?= BASE_URL ?>admin/menu.php" class="<?= $page=='menu.php'?'active':'' ?>">🍽️ Menu</a>
        <a href="<?= BASE_URL ?>admin/orders.php" class="<?= in_array($page,['orders.php','order_details.php'])?'active':'' ?>">🧾 Orders</a>
        <a href="<?= BASE_URL ?>admin/tables.php" class="<?= $page=='tables.php'?'active':'' ?>">🪑 Tables</a>
        <a href="<?= BASE_URL ?>admin/staff.php" class="<?= $page=='staff.php'?'active':'' ?>">👥 Staff</a>
        <a href="<?= BASE_URL ?>admin/reports.php" class="<?= $page=='reports.php'?'active':'' ?>">📈 Reports</a>
    </nav>
    <div class="user-box">
        <div class="u-name"><?= clean($_SESSION['name']) ?></div>
        <div class="u-role">Administrator</div>
        <a class="logout-link" href="<?= BASE_URL ?>auth/logout.php">Log out →</a>
    </div>
</aside>
