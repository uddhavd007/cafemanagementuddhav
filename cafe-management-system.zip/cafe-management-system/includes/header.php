<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? clean($pageTitle) . ' – ' : '' ?><?= SITE_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="app-shell">
<?php
if (current_role() === 'admin') {
    include __DIR__ . '/sidebar_admin.php';
} elseif (current_role() === 'staff') {
    include __DIR__ . '/sidebar_staff.php';
}
?>
<main class="main">
    <div class="topbar">
        <div>
            <h1><?= clean($pageTitle ?? '') ?></h1>
            <?php if (!empty($pageSubtitle)): ?><div class="subtitle"><?= clean($pageSubtitle) ?></div><?php endif; ?>
        </div>
        <?php if (!empty($topbarActions)) echo $topbarActions; ?>
    </div>
    <?php include __DIR__ . '/flash.php'; ?>
