<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? clean($pageTitle) . ' – ' : '' ?><?= SITE_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<nav class="public-nav">
    <div class="brand">☕ Brew & Bean</div>
    <div class="links">
        <a href="<?= BASE_URL ?>customer/menu.php">Menu</a>
        <?php if (is_logged_in() && current_role() === 'customer'): ?>
            <a href="<?= BASE_URL ?>customer/cart.php">🛒 Cart<?php if (!empty($cartCount)): ?> (<?= $cartCount ?>)<?php endif; ?></a>
            <a href="<?= BASE_URL ?>customer/orders.php">My Orders</a>
            <span class="muted">Hi, <?= clean($_SESSION['name']) ?></span>
            <a class="btn btn-outline btn-sm" href="<?= BASE_URL ?>auth/logout.php">Log out</a>
        <?php else: ?>
            <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>auth/login.php">Log in</a>
        <?php endif; ?>
    </div>
</nav>
<div class="public-wrap">
<?php include __DIR__ . '/flash.php'; ?>
