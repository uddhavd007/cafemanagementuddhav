<?php
/**
 * Common helper functions
 */

function clean($value) {
    return htmlspecialchars(trim($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header("Location: " . BASE_URL . ltrim($path, '/'));
    exit;
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function current_role() {
    return $_SESSION['role'] ?? null;
}

function require_role($roles) {
    $roles = (array) $roles;
    if (!is_logged_in() || !in_array(current_role(), $roles, true)) {
        redirect('auth/login.php');
    }
}

function format_price($amount) {
    return CURRENCY . number_format((float) $amount, 2);
}

function flash($key, $message = null) {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function generate_order_number() {
    return 'ORD' . date('ymd') . strtoupper(substr(uniqid(), -5));
}

function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function get_cart_count($pdo) {
    if (!is_logged_in() || current_role() !== 'customer') return 0;
    $stmt = $pdo->prepare('SELECT COALESCE(SUM(quantity),0) c FROM cart_items WHERE customer_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return (int) $stmt->fetchColumn();
}

function status_badge_class($status) {
    $map = [
        'pending'    => 'badge-pending',
        'preparing'  => 'badge-preparing',
        'ready'      => 'badge-ready',
        'served'     => 'badge-served',
        'completed'  => 'badge-completed',
        'cancelled'  => 'badge-cancelled',
        'available'  => 'badge-available',
        'occupied'   => 'badge-occupied',
        'reserved'   => 'badge-reserved',
        'paid'       => 'badge-completed',
        'unpaid'     => 'badge-pending',
        'active'     => 'badge-available',
        'inactive'   => 'badge-cancelled',
    ];
    return $map[$status] ?? 'badge-pending';
}
