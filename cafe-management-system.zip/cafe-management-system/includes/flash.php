<?php
$ok = flash('success');
$err = flash('error');
?>
<?php if ($ok): ?><div class="alert alert-success">✓ <?= clean($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error">⚠ <?= clean($err) ?></div><?php endif; ?>
