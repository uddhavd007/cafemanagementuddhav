-- ============================================================
-- Brew & Bean Cafe Management System - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS cafe_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cafe_management;

-- ------------------------------------------------------------
-- USERS (admin / staff / customer share one table with a role)
-- ------------------------------------------------------------
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    role ENUM('admin','staff','customer') NOT NULL DEFAULT 'customer',
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- CATEGORIES
-- ------------------------------------------------------------
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- MENU ITEMS
-- ------------------------------------------------------------
CREATE TABLE menu_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(120) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255) DEFAULT NULL,
    is_available TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- CAFE TABLES (physical dine-in tables)
-- ------------------------------------------------------------
CREATE TABLE cafe_tables (
    table_id INT AUTO_INCREMENT PRIMARY KEY,
    table_number VARCHAR(10) NOT NULL UNIQUE,
    capacity INT NOT NULL DEFAULT 2,
    status ENUM('available','occupied','reserved') NOT NULL DEFAULT 'available'
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- ORDERS
-- ------------------------------------------------------------
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(20) NOT NULL UNIQUE,
    customer_id INT DEFAULT NULL,
    table_id INT DEFAULT NULL,
    staff_id INT DEFAULT NULL,
    order_type ENUM('dine_in','takeaway') NOT NULL DEFAULT 'dine_in',
    status ENUM('pending','preparing','ready','served','completed','cancelled') NOT NULL DEFAULT 'pending',
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount DECIMAL(10,2) NOT NULL DEFAULT 0,
    grand_total DECIMAL(10,2) NOT NULL DEFAULT 0,
    payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
    payment_method ENUM('cash','card','upi') DEFAULT NULL,
    notes VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (table_id) REFERENCES cafe_tables(table_id) ON DELETE SET NULL,
    FOREIGN KEY (staff_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- ORDER ITEMS
-- ------------------------------------------------------------
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    item_id INT DEFAULT NULL,
    item_name VARCHAR(120) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES menu_items(item_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- CART (persistent server-side cart per customer, pre-checkout)
-- ------------------------------------------------------------
CREATE TABLE cart_items (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    item_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES menu_items(item_id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (customer_id, item_id)
) ENGINE=InnoDB;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Default admin: email admin@brewbean.com / password: admin123
INSERT INTO users (name, email, password, phone, role) VALUES
('Cafe Admin', 'admin@brewbean.com', '$2b$10$TTCABCDsuPsoOjzHNa6uvuT90HzGDEPOyVfQWf0jsWtkw7MP46.9u', '9999900000', 'admin');

-- Sample staff: staff@brewbean.com / staff123
INSERT INTO users (name, email, password, phone, role) VALUES
('Riya Sharma', 'staff@brewbean.com', '$2b$10$P8vGa4X2mrFrRzG6NFGJ.eaUdzfW0shrJ7shKRs1FyXILIhpOVX5i', '9999911111', 'staff');

-- Sample customer: customer@brewbean.com / customer123
INSERT INTO users (name, email, password, phone, role) VALUES
('Aman Verma', 'customer@brewbean.com', '$2b$10$vuHWbkySbJCihz56JpHZ.O/7Dvnpv/.qsu8loZcSuSrNi.AK.vjxy', '9999922222', 'customer');

INSERT INTO categories (name, description) VALUES
('Hot Coffee', 'Freshly brewed hot coffee'),
('Cold Coffee', 'Iced and blended coffee'),
('Tea', 'Assorted teas'),
('Bakery', 'Fresh baked items'),
('Snacks', 'Light bites and snacks'),
('Beverages', 'Juices, mocktails and more');

INSERT INTO menu_items (category_id, name, description, price, is_available) VALUES
(1, 'Espresso', 'Rich and bold single shot', 90.00, 1),
(1, 'Cappuccino', 'Espresso with steamed milk foam', 140.00, 1),
(1, 'Cafe Latte', 'Smooth espresso with steamed milk', 150.00, 1),
(1, 'Americano', 'Espresso diluted with hot water', 110.00, 1),
(2, 'Cold Coffee', 'Chilled blended coffee with ice cream', 160.00, 1),
(2, 'Iced Latte', 'Espresso over ice with cold milk', 170.00, 1),
(2, 'Frappe', 'Whipped iced coffee blend', 180.00, 1),
(3, 'Masala Chai', 'Spiced Indian tea', 60.00, 1),
(3, 'Green Tea', 'Light and refreshing', 70.00, 1),
(4, 'Butter Croissant', 'Flaky French pastry', 90.00, 1),
(4, 'Blueberry Muffin', 'Soft muffin with blueberries', 100.00, 1),
(4, 'Chocolate Brownie', 'Fudgy chocolate brownie', 110.00, 1),
(5, 'Veg Sandwich', 'Grilled vegetable sandwich', 130.00, 1),
(5, 'French Fries', 'Crispy salted fries', 100.00, 1),
(5, 'Nachos', 'Loaded cheesy nachos', 150.00, 1),
(6, 'Fresh Lime Soda', 'Sweet and tangy lime soda', 80.00, 1),
(6, 'Cold Lemonade', 'Chilled homemade lemonade', 85.00, 1);

INSERT INTO cafe_tables (table_number, capacity, status) VALUES
('T1', 2, 'available'),
('T2', 2, 'available'),
('T3', 4, 'available'),
('T4', 4, 'available'),
('T5', 6, 'available'),
('T6', 4, 'available');
