// ==== Take Order page logic ====
let cart = {}; // item_id -> {name, price, qty}

const orderTypeEl = document.getElementById('orderType');
const tableWrap = document.getElementById('tableSelectWrap');
const tableSelect = document.getElementById('tableSelect');
const cartEl = document.getElementById('orderCart');
const emptyMsg = document.getElementById('emptyCartMsg');
const subtotalEl = document.getElementById('cartSubtotal');
const taxEl = document.getElementById('cartTax');
const totalEl = document.getElementById('cartTotal');
const placeBtn = document.getElementById('placeOrderBtn');

function fmt(n) { return CURRENCY + n.toFixed(2); }

function toggleTableVisibility() {
    tableWrap.style.display = orderTypeEl.value === 'dine_in' ? 'block' : 'none';
}
orderTypeEl.addEventListener('change', toggleTableVisibility);
toggleTableVisibility();

document.querySelectorAll('.add-to-order').forEach(btn => {
    btn.addEventListener('click', () => {
        const card = btn.closest('.menu-card');
        const id = card.dataset.itemId;
        const name = card.dataset.name;
        const price = parseFloat(card.dataset.price);
        if (!cart[id]) cart[id] = { name, price, qty: 0 };
        cart[id].qty += 1;
        renderCart();
    });
});

function changeQty(id, delta) {
    if (!cart[id]) return;
    cart[id].qty += delta;
    if (cart[id].qty <= 0) delete cart[id];
    renderCart();
}

function renderCart() {
    const ids = Object.keys(cart);
    cartEl.innerHTML = '';
    if (ids.length === 0) {
        cartEl.appendChild(emptyMsg);
        placeBtn.disabled = true;
    } else {
        placeBtn.disabled = false;
        ids.forEach(id => {
            const row = document.createElement('div');
            row.className = 'ti-row';
            row.style.alignItems = 'center';
            row.innerHTML = `
                <span class="ti-name">${cart[id].name}</span>
                <span class="qty-control">
                    <button type="button" onclick="changeQty('${id}', -1)">−</button>
                    <span>${cart[id].qty}</span>
                    <button type="button" onclick="changeQty('${id}', 1)">+</button>
                </span>`;
            cartEl.appendChild(row);
        });
    }
    let subtotal = 0;
    ids.forEach(id => subtotal += cart[id].price * cart[id].qty);
    const tax = subtotal * TAX_RATE;
    subtotalEl.textContent = fmt(subtotal);
    taxEl.textContent = fmt(tax);
    totalEl.textContent = fmt(subtotal + tax);
}

placeBtn.addEventListener('click', async () => {
    const orderType = orderTypeEl.value;
    const tableId = orderType === 'dine_in' ? tableSelect.value : null;
    if (orderType === 'dine_in' && !tableId) {
        alert('Please select a table for dine-in orders.');
        return;
    }
    const items = Object.entries(cart).map(([item_id, v]) => ({
        item_id, name: v.name, price: v.price, quantity: v.qty
    }));
    placeBtn.disabled = true;
    placeBtn.textContent = 'Placing order…';

    const res = await postJSON(AJAX_URL, {
        order_type: orderType,
        table_id: tableId,
        notes: document.getElementById('orderNotes').value,
        items
    });

    if (res.success) {
        window.location.href = res.redirect;
    } else {
        alert(res.message || 'Could not place order.');
        placeBtn.disabled = false;
        placeBtn.textContent = 'Place Order';
    }
});
