<?php
require_once __DIR__ . '/../config/config.php';
require_role('customer');

$pageTitle = 'My Orders';
$cartCount = get_cart_count($pdo);

$stmt = $pdo->prepare("
    SELECT o.*, t.table_number FROM orders o
    LEFT JOIN cafe_tables t ON o.table_id = t.table_id
    WHERE o.customer_id = ?
    ORDER BY o.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

include __DIR__ . '/../includes/header_public.php';
?>

<h1>My Orders</h1>

<?php if (!$orders): ?>
    <div class="empty-state">
        <div class="icon">🧾</div>
        <p>You haven't placed any orders yet. <a class="gold" href="menu.php">Browse the menu</a></p>
    </div>
<?php else: ?>
    <div class="card">
        <table class="data-table">
            <thead><tr><th>Order #</th><th>Type</th><th>Status</th><th>Payment</th><th>Total</th><th>Date</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($orders as $o): ?>
                <tr>
                    <td class="gold" style="font-family:var(--font-mono); font-size:12.5px;"><?= clean($o['order_number']) ?></td>
                    <td><?= $o['table_number'] ? 'Table ' . clean($o['table_number']) : ucfirst($o['order_type']) ?></td>
                    <td><span class="badge <?= status_badge_class($o['status']) ?>"><?= clean($o['status']) ?></span></td>
                    <td><span class="badge <?= status_badge_class($o['payment_status']) ?>"><?= clean($o['payment_status']) ?></span></td>
                    <td><?= format_price($o['grand_total']) ?></td>
                    <td class="muted" style="font-size:12px;"><?= date('d M, h:i A', strtotime($o['created_at'])) ?></td>
                    <td><a class="btn btn-outline btn-sm" href="invoice.php?id=<?= $o['order_id'] ?>">View</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer_public.php'; ?>
