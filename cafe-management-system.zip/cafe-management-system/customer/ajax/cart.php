<?php
require_once __DIR__ . '/../../config/config.php';
require_role('customer');

$action = $_GET['action'] ?? '';
$customerId = $_SESSION['user_id'];

switch ($action) {

    case 'add':
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $stmt = $pdo->prepare('INSERT INTO cart_items (customer_id, item_id, quantity) VALUES (?, ?, 1)
            ON DUPLICATE KEY UPDATE quantity = quantity + 1');
        $stmt->execute([$customerId, $itemId]);
        redirect('customer/menu.php');
        break;

    case 'update':
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $qty = (int) ($_POST['quantity'] ?? 1);
        if ($qty <= 0) {
            $pdo->prepare('DELETE FROM cart_items WHERE customer_id = ? AND item_id = ?')->execute([$customerId, $itemId]);
        } else {
            $pdo->prepare('UPDATE cart_items SET quantity = ? WHERE customer_id = ? AND item_id = ?')->execute([$qty, $customerId, $itemId]);
        }
        redirect('customer/cart.php');
        break;

    case 'remove':
        $itemId = (int) ($_POST['item_id'] ?? $_GET['item_id'] ?? 0);
        $pdo->prepare('DELETE FROM cart_items WHERE customer_id = ? AND item_id = ?')->execute([$customerId, $itemId]);
        redirect('customer/cart.php');
        break;

    default:
        redirect('customer/menu.php');
}
