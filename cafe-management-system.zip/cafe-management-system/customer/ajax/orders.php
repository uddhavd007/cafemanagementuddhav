<?php
require_once __DIR__ . '/../../config/config.php';
require_role('customer');

$action = $_GET['action'] ?? '';
$customerId = $_SESSION['user_id'];

if ($action === 'checkout') {
    $orderType = ($_POST['order_type'] ?? 'dine_in') === 'takeaway' ? 'takeaway' : 'dine_in';
    $tableId = $orderType === 'dine_in' ? (int) ($_POST['table_id'] ?? 0) : null;
    $notes = trim($_POST['notes'] ?? '');

    if ($orderType === 'dine_in' && !$tableId) {
        flash('error', 'Please select a table for dine-in orders.');
        redirect('customer/cart.php');
    }

    $stmt = $pdo->prepare("
        SELECT ci.item_id, ci.quantity, mi.name, mi.price
        FROM cart_items ci JOIN menu_items mi ON ci.item_id = mi.item_id
        WHERE ci.customer_id = ?
    ");
    $stmt->execute([$customerId]);
    $cartItems = $stmt->fetchAll();

    if (!$cartItems) {
        flash('error', 'Your cart is empty.');
        redirect('customer/cart.php');
    }

    $subtotal = 0;
    foreach ($cartItems as $c) $subtotal += $c['price'] * $c['quantity'];
    $tax = round($subtotal * TAX_RATE, 2);
    $grandTotal = round($subtotal + $tax, 2);
    $orderNumber = generate_order_number();

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO orders
            (order_number, customer_id, table_id, order_type, status, subtotal, tax_amount, grand_total, notes)
            VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?)");
        $stmt->execute([$orderNumber, $customerId, $tableId ?: null, $orderType, $subtotal, $tax, $grandTotal, $notes]);
        $orderId = $pdo->lastInsertId();

        $itemStmt = $pdo->prepare("INSERT INTO order_items (order_id, item_id, item_name, price, quantity, subtotal)
            VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($cartItems as $c) {
            $itemStmt->execute([$orderId, $c['item_id'], $c['name'], $c['price'], $c['quantity'], $c['price'] * $c['quantity']]);
        }

        if ($tableId) {
            $pdo->prepare("UPDATE cafe_tables SET status = 'occupied' WHERE table_id = ?")->execute([$tableId]);
        }

        $pdo->prepare('DELETE FROM cart_items WHERE customer_id = ?')->execute([$customerId]);

        $pdo->commit();
        flash('success', 'Order placed! We\'ll get started right away.');
        redirect('customer/invoice.php?id=' . $orderId);
    } catch (Exception $e) {
        $pdo->rollBack();
        flash('error', 'Something went wrong placing your order. Please try again.');
        redirect('customer/cart.php');
    }
}

redirect('customer/menu.php');
