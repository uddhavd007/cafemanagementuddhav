<?php
require_once __DIR__ . '/../config/config.php';
require_role('customer');

$pageTitle = 'Your Cart';
$customerId = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT ci.*, mi.name, mi.price, mi.is_available
    FROM cart_items ci JOIN menu_items mi ON ci.item_id = mi.item_id
    WHERE ci.customer_id = ?
");
$stmt->execute([$customerId]);
$cartItems = $stmt->fetchAll();
$cartCount = array_sum(array_column($cartItems, 'quantity'));

$subtotal = 0;
foreach ($cartItems as $c) $subtotal += $c['price'] * $c['quantity'];
$tax = round($subtotal * TAX_RATE, 2);
$total = round($subtotal + $tax, 2);

$tables = $pdo->query("SELECT * FROM cafe_tables WHERE status != 'occupied' ORDER BY table_number")->fetchAll();

include __DIR__ . '/../includes/header_public.php';
?>

<h1>Your Cart</h1>

<?php if (!$cartItems): ?>
    <div class="empty-state">
        <div class="icon">🛒</div>
        <p>Your cart is empty. <a class="gold" href="menu.php">Browse the menu</a></p>
    </div>
<?php else: ?>
    <div class="grid" style="grid-template-columns: 2fr 1fr; align-items:start; gap:20px;">
        <div class="card">
            <?php foreach ($cartItems as $c): ?>
                <div class="ti-row" style="align-items:center; padding:10px 0; border-bottom:1px solid var(--border);">
                    <div>
                        <div class="ti-name"><?= clean($c['name']) ?></div>
                        <div class="muted" style="font-size:12px;"><?= format_price($c['price']) ?> each</div>
                    </div>
                    <div class="flex gap-8" style="align-items:center;">
                        <form action="ajax/cart.php?action=update" method="POST" class="flex gap-8">
                            <input type="hidden" name="item_id" value="<?= $c['item_id'] ?>">
                            <input type="number" name="quantity" value="<?= $c['quantity'] ?>" min="1" style="width:60px; margin-bottom:0;" onchange="this.form.submit()">
                        </form>
                        <span class="gold" style="min-width:70px; text-align:right;"><?= format_price($c['price']*$c['quantity']) ?></span>
                        <form action="ajax/cart.php?action=remove" method="POST">
                            <input type="hidden" name="item_id" value="<?= $c['item_id'] ?>">
                            <button class="btn btn-danger btn-sm" data-confirm="Remove this item?">×</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card">
            <h3 class="mt-0">Checkout</h3>
            <form action="ajax/orders.php?action=checkout" method="POST">
                <label>Order Type</label>
                <select name="order_type" id="orderTypeSelect" onchange="document.getElementById('tableWrap').style.display = this.value=='dine_in' ? 'block' : 'none'">
                    <option value="dine_in">Dine-in</option>
                    <option value="takeaway">Takeaway</option>
                </select>
                <div id="tableWrap">
                    <label>Table</label>
                    <select name="table_id">
                        <option value="">Select a table…</option>
                        <?php foreach ($tables as $t): ?>
                            <option value="<?= $t['table_id'] ?>"><?= clean($t['table_number']) ?> (seats <?= (int)$t['capacity'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <label>Notes (optional)</label>
                <textarea name="notes" rows="2" placeholder="Any special request?"></textarea>

                <div class="ti-row"><span class="muted">Subtotal</span><span><?= format_price($subtotal) ?></span></div>
                <div class="ti-row"><span class="muted">Tax (<?= TAX_RATE*100 ?>%)</span><span><?= format_price($tax) ?></span></div>
                <div class="ticket-total" style="margin:8px 0 16px;"><span>Total</span><span><?= format_price($total) ?></span></div>

                <button type="submit" class="btn btn-primary btn-block">Place Order</button>
            </form>
        </div>
    </div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer_public.php'; ?>
