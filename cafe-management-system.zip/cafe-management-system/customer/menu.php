<?php
require_once __DIR__ . '/../config/config.php';

$pageTitle = 'Menu';
$cartCount = get_cart_count($pdo);

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$items = $pdo->query("SELECT * FROM menu_items WHERE is_available = 1 ORDER BY category_id, name")->fetchAll();

$itemsByCat = [];
foreach ($items as $it) { $itemsByCat[$it['category_id']][] = $it; }

// mark which items are already in the customer's cart
$inCart = [];
if (is_logged_in() && current_role() === 'customer') {
    $stmt = $pdo->prepare('SELECT item_id, quantity FROM cart_items WHERE customer_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    foreach ($stmt->fetchAll() as $row) $inCart[$row['item_id']] = $row['quantity'];
}

include __DIR__ . '/../includes/header_public.php';
?>

<div class="text-center" style="margin-bottom:30px;">
    <h1 style="font-size:34px;">Our Menu</h1>
    <p>Freshly brewed coffee, tea and bites — order for dine-in or takeaway.</p>
</div>

<?php foreach ($categories as $c): if (empty($itemsByCat[$c['category_id']])) continue; ?>
    <h3 class="menu-cat-title"><?= clean($c['name']) ?></h3>
    <div class="menu-grid">
        <?php foreach ($itemsByCat[$c['category_id']] as $it): ?>
            <div class="menu-card">
                <div class="m-name"><?= clean($it['name']) ?></div>
                <div class="m-desc"><?= clean($it['description']) ?></div>
                <div class="m-footer">
                    <span class="m-price"><?= format_price($it['price']) ?></span>
                    <?php if (is_logged_in() && current_role() === 'customer'): ?>
                        <form action="ajax/cart.php?action=add" method="POST">
                            <input type="hidden" name="item_id" value="<?= $it['item_id'] ?>">
                            <button type="submit" class="btn btn-outline btn-sm"><?= isset($inCart[$it['item_id']]) ? '✓ In Cart (' . $inCart[$it['item_id']] . ')' : '+ Add' ?></button>
                        </form>
                    <?php elseif (is_logged_in()): ?>
                        <span class="muted" style="font-size:12px;">Staff/Admin view</span>
                    <?php else: ?>
                        <a href="<?= BASE_URL ?>auth/login.php" class="btn btn-outline btn-sm">Log in to order</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>

<?php include __DIR__ . '/../includes/footer_public.php'; ?>
