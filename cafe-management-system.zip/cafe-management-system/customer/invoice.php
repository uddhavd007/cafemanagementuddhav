<?php
require_once __DIR__ . '/../config/config.php';
require_role('customer');

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("
    SELECT o.*, t.table_number FROM orders o
    LEFT JOIN cafe_tables t ON o.table_id = t.table_id
    WHERE o.order_id = ? AND o.customer_id = ?
");
$stmt->execute([$id, $_SESSION['user_id']]);
$order = $stmt->fetch();
if (!$order) { flash('error', 'Order not found.'); redirect('customer/orders.php'); }

$itemStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->execute([$id]);
$items = $itemStmt->fetchAll();

$pageTitle = 'Order ' . $order['order_number'];
$cartCount = get_cart_count($pdo);

include __DIR__ . '/../includes/header_public.php';
?>

<div style="max-width:460px; margin:0 auto;">
    <div class="ticket" id="printArea">
        <div class="ticket-head">
            <div>
                <div class="t-num"><?= clean($order['order_number']) ?></div>
                <div class="t-meta"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></div>
            </div>
            <span class="badge <?= status_badge_class($order['status']) ?>"><?= clean($order['status']) ?></span>
        </div>
        <p class="muted" style="margin:0;">
            <?= $order['table_number'] ? 'Table ' . clean($order['table_number']) : ucfirst(str_replace('_',' ',$order['order_type'])) ?>
        </p>
        <div class="ticket-items">
            <?php foreach ($items as $it): ?>
                <div class="ti-row">
                    <span class="ti-name"><?= clean($it['item_name']) ?> <span class="ti-qty">× <?= (int)$it['quantity'] ?></span></span>
                    <span><?= format_price($it['subtotal']) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="ti-row"><span class="muted">Subtotal</span><span><?= format_price($order['subtotal']) ?></span></div>
        <div class="ti-row"><span class="muted">Tax</span><span><?= format_price($order['tax_amount']) ?></span></div>
        <?php if ($order['discount'] > 0): ?><div class="ti-row"><span class="muted">Discount</span><span>-<?= format_price($order['discount']) ?></span></div><?php endif; ?>
        <div class="ticket-total" style="margin-top:8px;"><span>Total</span><span><?= format_price($order['grand_total']) ?></span></div>
        <div class="ticket-foot">
            <span class="badge <?= status_badge_class($order['payment_status']) ?>"><?= clean($order['payment_status']) ?><?= $order['payment_method'] ? ' · ' . strtoupper($order['payment_method']) : '' ?></span>
        </div>
    </div>

    <div class="flex gap-8" style="margin-top:16px;">
        <a href="orders.php" class="btn btn-outline btn-block">← My Orders</a>
        <button onclick="window.print()" class="btn btn-primary btn-block">🖨 Print</button>
    </div>
</div>

<style>
@media print {
    .public-nav, .flex.gap-8 { display: none !important; }
    body { background: #fff; color: #000; }
    #printArea { border: 1px solid #000; }
}
</style>

<?php include __DIR__ . '/../includes/footer_public.php'; ?>
