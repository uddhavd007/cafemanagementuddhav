<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) {
    switch (current_role()) {
        case 'admin':    redirect('admin/dashboard.php');
        case 'staff':    redirect('staff/dashboard.php');
        default:         redirect('customer/menu.php');
    }
} else {
    redirect('customer/menu.php'); // public menu is the storefront landing page
}
