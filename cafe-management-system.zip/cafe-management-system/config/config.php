<?php
/**
 * Global configuration - included at the top of every page.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('SITE_NAME', 'Brew & Bean Cafe');
define('CURRENCY', '₹');
define('TAX_RATE', 0.05); // 5% tax

// BASE_URL auto-detects the folder the project is running from
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
// Walk up to the project root (folder containing this config file's parent)
$root = preg_replace('#/(admin|staff|customer|auth)(/ajax)?$#', '', $scriptDir);
define('BASE_URL', $protocol . $_SERVER['HTTP_HOST'] . $root . '/');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../includes/functions.php';
